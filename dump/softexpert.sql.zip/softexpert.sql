-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30-Abr-2023 às 07:54
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `softexpert`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `adm_menu`
--

CREATE TABLE `adm_menu` (
  `id` int(11) NOT NULL,
  `adm_menu_id` int(11) DEFAULT NULL,
  `icone` varchar(50) DEFAULT NULL,
  `nome` varchar(50) NOT NULL,
  `link` mediumtext DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `tipo` enum('geral','vistoriador','parceiro','conferente','financeiro') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `adm_menu`
--

INSERT INTO `adm_menu` (`id`, `adm_menu_id`, `icone`, `nome`, `link`, `status`, `tipo`) VALUES
(3, NULL, 'users', 'Usu&aacute;rios', 'usuariosList.php', 1, 'geral'),
(5, NULL, 'dollar-sign', 'Serviços', 'servicosList.php', 1, 'geral');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cad_produtos`
--

CREATE TABLE `cad_produtos` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` decimal(10,2) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `imagem` mediumtext DEFAULT NULL,
  `dt_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `dt_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cad_usuarios`
--

CREATE TABLE `cad_usuarios` (
  `id` int(11) NOT NULL,
  `uniqid` varchar(255) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `celular` varchar(20) DEFAULT NULL,
  `tipo` enum('geral','vistoriador','parceiro','conferente','financeiro') NOT NULL,
  `senha` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL,
  `dt_create` datetime NOT NULL,
  `dt_update` datetime DEFAULT NULL,
  `dt_delete` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `cad_usuarios`
--

INSERT INTO `cad_usuarios` (`id`, `uniqid`, `nome`, `email`, `celular`, `tipo`, `senha`, `status`, `dt_create`, `dt_update`, `dt_delete`) VALUES
(1, '649eedd21c2fde9407c77880d1a1a54a', 'Pedro Azeredo', 'pedro.azeredo93@gmail.com', NULL, 'geral', '31f465fc1ceb73d4da5c375c22ab9d18', 1, '2023-04-28 15:25:11', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_acessos_usuarios`
--

CREATE TABLE `log_acessos_usuarios` (
  `cad_usuario_id` int(11) NOT NULL,
  `data` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `log_acessos_usuarios`
--

INSERT INTO `log_acessos_usuarios` (`cad_usuario_id`, `data`) VALUES
(1, '2023-04-29 02:01:45'),
(5, '2023-04-29 02:07:24'),
(3, '2023-04-29 02:17:30'),
(1, '2023-04-29 02:18:30'),
(3, '2023-04-30 02:32:14'),
(1, '2023-04-30 02:33:51');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_produto`
--

CREATE TABLE `tipo_produto` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `adm_menu`
--
ALTER TABLE `adm_menu`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `cad_produtos`
--
ALTER TABLE `cad_produtos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `cad_usuarios`
--
ALTER TABLE `cad_usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniqid` (`uniqid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices para tabela `tipo_produto`
--
ALTER TABLE `tipo_produto`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `adm_menu`
--
ALTER TABLE `adm_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT de tabela `cad_produtos`
--
ALTER TABLE `cad_produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `cad_usuarios`
--
ALTER TABLE `cad_usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `tipo_produto`
--
ALTER TABLE `tipo_produto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
